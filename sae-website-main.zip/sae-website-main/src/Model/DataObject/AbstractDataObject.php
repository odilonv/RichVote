<?php
namespace App\Model\DataObject;

abstract class AbstractDataObject{

    public abstract function formatTableau(): array;
    //public abstract function getId(): ?string;


}