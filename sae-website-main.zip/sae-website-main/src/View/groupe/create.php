<div class="block">
    <div class="text-box">
    <form method="post" action="frontController.php?controller=groupe&action=created">
        <fieldset>
            <br>
            <h1>Créer un nouveau groupe</h1>
            <div class="ligneCent"><div class="ligne"></div></div>
            <div class="descG"></div>

            <h3><label for="nG"> Nom du groupe: </label></h3>
            <input type="text" id="nG" name="nomGroupe" placeholder="Les Fans De RichVote">

            <div class="ligneCent"> <input class="optQuestion" type="submit" value="sauvegarder"/></div>
        </fieldset>

    </form>
    </div>
</div>