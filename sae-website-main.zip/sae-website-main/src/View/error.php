<?php
/**
 * @var string $code
 * @var string $message
 */
?>
<div class="block">
    <div class="text-box" id="formConnect">
        <img src="../assets/img/logo.png" alt="RichVote" id="logo">
        <h1><?=$code?></h1>
        <br>
        <p><?=$message?></p>
        <br>

    </div>
</div>