<div class="block">
    <div class="text-box">
        <div class="ligneExt">
            <a class="optQuestion" id="fleche" href=<?=$_SERVER['HTTP_REFERER']?>>↩</a>
            <img src="../assets/img/logo.png" alt="RichVote" id="logo">
        </div>
        <div class="ligneCent">

            <h2>
                Qu'est ce que le jugement majoritaire ?
            </h2></div>
        <div class="descG"></div>
        <p>
            Le jugement majoritaire est une méthode de vote par valeurs
            (les électeurs attribuent une mention à chaque candidat et peuvent attribuer la même mention à plusieurs candidats)
            pour laquelle la détermination du gagnant se fait par la médiane plutôt que par la moyenne.
        </p>
        <div class="descG"></div>
    </div>
</div>