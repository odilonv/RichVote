<div class="block">
    <div class="text-box">
        <div class="ligneExt">
            <a class="optQuestion" id="fleche" href=<?=$_SERVER['HTTP_REFERER']?>>↩</a>
            <img src="../assets/img/logo.png" alt="RichVote" id="logo">
        </div>
        <div class="ligneCent">

            <h2>
                Qu'est ce que la redaction ?
            </h2></div>
        <div class="descG"></div>
        <p>
            La redaction est la période où des participants peuvent faire des propositions de réponses.
        </p>
        <div class="descG"></div>
    </div>
</div>