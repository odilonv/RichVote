<div class="block">
    <div class="text-box">
        <div class="ligneExt">
            <a class="optQuestion" id="fleche" href=<?=$_SERVER['HTTP_REFERER']?>>↩</a>
            <img src="../assets/img/logo.png" alt="RichVote" id="logo">
        </div>
        <div class="ligneCent">

            <h2>
                Qu'est ce que le scrutin Majoritaire Plurinominal ?
            </h2></div>
        <div class="descG"></div>
        <p>
            Le scrutin majoritaire plurinominal est un système électoral dans lequel plusieurs personnes sont élues au cours d'un même scrutin (scrutin plurinominal) et où les candidats ayant obtenu le plus de voix sont élus (scrutin majoritaire).
        </p>
        <div class="descG"></div>
    </div>
</div>