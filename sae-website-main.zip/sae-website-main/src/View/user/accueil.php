
<header>
    <div class="scroll"> <span>scroll &#10132</span></div>
    <div class="ligne"></div>
    <div class="blocvid">
    <video autoplay="autoplay" muted="" loop="infinite" src="../assets/img/anim.webm"></video>
    </div>
    <div class="ligne"></div>
</header>
<div class="block">
        <div class="text-box">
            <img src="../assets/img/logo.png" alt="RichVote" id="logo">
            <p>
                RichVote est un site de vote. Il possède le système de vote le plus élaboré et le plus
                sûr que l'on peut retrouver sur le web.
            </p>
            <p>
                Suivez vos différents sujets en vous connectant <a href="frontController.php?controller=user&action=connexion">ici</a>.
            </p>
            <p>
                Si vous n'êtes pas inscrit, ne tardez plus !
                Vous pouvez être nommé à différents rôles, vous avez juste à cliquer <a href="frontController.php?controller=user&action=inscription">ici</a>.
            </p>
        </div>
</div>
